#!/usr/bin/env python3
import subprocess
import re

print("\033[1;34m🐉 Kali GPT – Wi‑Fi Password Viewer (Linux)\033[0m\n")

try:
    # Get list of saved wifi connections
    data = subprocess.check_output(['nmcli', '-t', '-f', 'NAME', 'connection', 'show'], text=True)
    profiles = data.strip().split('\n')

    print("\033[1;32m{:<30} | {:<}\033[0m".format("Wi‑Fi Name", "Password"))
    print("-" * 50)

    for profile in profiles:
        try:
            # Get wifi password
            res = subprocess.check_output(['nmcli', '-s', '-g', '802-11-wireless-security.psk', 'connection', 'show', profile], text=True).strip()
            password = res if res else "None"
            print("{:<30} | {:<}".format(profile, password))
        except subprocess.CalledProcessError:
            print("{:<30} | {:<}".format(profile, "❌ Error / No password"))

except Exception as e:
    print("\033[1;31m❌ Error:\033[0m", e)

print("\n\033[1;34mDone. Only shows passwords saved on this system.\033[0m")
